#!/data/data/com.termux/files/usr/bin/bash
#
# THE KILLER — install.sh
# Installs required Termux packages and sets up folders/permissions.

set -e

echo "== The Killer Server — Install =="

echo "[1/4] Updating packages..."
pkg update -y
pkg upgrade -y

echo "[2/4] Installing php, git, nano, curl, wget, cloudflared, zip, unzip..."
pkg install php git nano curl wget cloudflared zip unzip -y

echo "[3/4] Setting permissions..."
chmod +x killer
chmod +x killer-stop

echo "[4/4] Preparing public_html..."
mkdir -p ~/public_html
cp -n public_html/index.php ~/public_html/index.php 2>/dev/null || true
cp -n public_html/filemanager.php ~/public_html/filemanager.php 2>/dev/null || true

echo ""
echo "Install complete."
echo ""
echo "Next steps:"
echo "  1. cloudflared tunnel login"
echo "  2. cloudflared tunnel create killer"
echo "  3. Edit ~/.cloudflared/config.yml  (copy config.yml.example and fill in your tunnel ID + domain)"
echo "  4. cloudflared tunnel route dns killer yourdomain.com"
echo "  5. ./killer"
echo ""
echo "IMPORTANT: open public_html/filemanager.php and change the default admin"
echo "password before your domain goes live. See README.md, section 'Securing the File Manager'."
