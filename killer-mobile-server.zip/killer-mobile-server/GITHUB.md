# 📤 Uploading The Killer to GitHub

This project's `.gitignore` already blocks `config.yml`, logs, and backup zips from being committed. Still — **before you run any command below**, do a manual check:

```bash
cd killer-mobile-server
git status
```

If you ever see `config.yml`, `.cloudflared/`, `*.log`, or a `*-backup.zip` listed as "to be committed," stop and fix `.gitignore` first.

---

## Step 1 — Create the repo on GitHub

1. Go to https://github.com/new
2. Repository name: `the-killer-mobile-server` (or whatever you like)
3. Visibility:
   - **Private** — recommended. Only you can see it.
   - **Public** — fine only after you've changed the file manager password (README step 7) and you're comfortable with the domain being effectively discoverable via commit history / repo description.
4. Do **not** tick "Add a README" (you already have one) — leave it empty.
5. Click **Create repository**. Copy the URL it shows you, e.g.:
   `https://github.com/YOUR_USERNAME/the-killer-mobile-server.git`

## Step 2 — One-time git identity setup (if not already done)

In Termux (or wherever you're pushing from):

```bash
git config --global user.name "Your Name"
git config --global user.email "you@example.com"
```

## Step 3 — Authentication (GitHub no longer accepts plain passwords)

Create a Personal Access Token:
1. https://github.com/settings/tokens → **Generate new token (classic)**
2. Scope: tick `repo`
3. Copy the token somewhere safe — GitHub only shows it once.

You'll paste this token in place of a password when you push.

*(Alternative: set up SSH keys instead — `ssh-keygen`, add the public key at https://github.com/settings/keys, then use the `git@github.com:...` remote URL instead of `https://`. Either works; HTTPS + token is simpler on a fresh Termux install.)*

## Step 4 — Initialize and push

```bash
cd killer-mobile-server
git init
git add .
git status          # <-- confirm config.yml / logs / backups are NOT listed
git commit -m "The Killer — mobile hosting server"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/the-killer-mobile-server.git
git push -u origin main
```

When prompted:
- Username: your GitHub username
- Password: **paste the Personal Access Token**, not your GitHub password

## Step 5 — Verify on GitHub

Open the repo in a browser and confirm:
- `config.yml` is **not** there (only `config.yml.example`)
- No `.cloudflared/` folder
- No `*.log` or `*-backup.zip` files

If any of those did get uploaded by mistake, don't just delete them in a new commit — git history keeps old commits. Instead:
```bash
git rm --cached path/to/leaked-file
echo "path/to/leaked-file" >> .gitignore
git commit -m "Remove leaked file"
git push
```
And if it was a real credential (tunnel ID + credentials JSON), also **revoke that tunnel in the Cloudflare dashboard** and create a fresh one — assume anything pushed to git history is compromised, deleting it later doesn't undo that.

## Future updates

Whenever you change files locally:

```bash
git add .
git status     # always check before committing
git commit -m "describe what changed"
git push
```

## Cloning onto a new phone (instead of zip backup/restore)

Since your repo won't contain the real config, cloning gives you the code but you'll still need to redo steps 5–7 of the main README (create tunnel, fill `config.yml`, set file manager password) on the new device.

```bash
pkg install git -y
git clone https://github.com/YOUR_USERNAME/the-killer-mobile-server.git
cd the-killer-mobile-server
chmod +x killer killer-stop install.sh
./install.sh
```
