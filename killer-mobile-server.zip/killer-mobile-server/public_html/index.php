<?php
/**
 * THE KILLER — Mobile Hosting Server
 * Landing / status dashboard.
 *
 * Advanced features on this page:
 *  - Live server clock + PHP/server info
 *  - Persistent visit counter (stored in visits.json, no database needed)
 *  - Auto-generated QR code linking to this site (for quick phone-to-phone sharing)
 *  - Dark theme, no external CSS/JS frameworks — loads instantly even on slow mobile data
 */

// ---- Visit counter (simple JSON file, no DB required) ----
$counterFile = __DIR__ . '/visits.json';
$visits = 0;
if (is_readable($counterFile)) {
    $data = json_decode(file_get_contents($counterFile), true);
    $visits = isset($data['visits']) ? (int)$data['visits'] : 0;
}
$visits++;
@file_put_contents($counterFile, json_encode(['visits' => $visits]));

// ---- Server info ----
$phpVersion   = phpversion();
$serverTime   = date('Y-m-d H:i:s');
$host         = $_SERVER['HTTP_HOST'] ?? 'your-domain.com';
$isHttps      = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
                || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
$scheme       = $isHttps ? 'https' : 'http';
$fullUrl      = $scheme . '://' . $host . '/';
$qrUrl        = 'https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=' . urlencode($fullUrl);

// ---- Personal info (edit these) ----
$ownerName  = 'Al Mamun Sheikh';
$ownerPhone = '09638471147';
$ownerEmail = 'info@skyhostr.com';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>The Killer — <?php echo htmlspecialchars($host); ?></title>
<style>
  :root{
    --bg:#0a0a0f;
    --card:#13131c;
    --accent:#ff2b4d;
    --accent2:#7c3aed;
    --text:#e8e8ee;
    --muted:#8b8b9a;
    --border:#232331;
  }
  *{box-sizing:border-box;}
  body{
    margin:0;
    min-height:100vh;
    font-family:'Segoe UI', Arial, sans-serif;
    color:var(--text);
    background:
      radial-gradient(circle at 20% 0%, rgba(255,43,77,0.15), transparent 40%),
      radial-gradient(circle at 80% 100%, rgba(124,58,237,0.18), transparent 45%),
      var(--bg);
    display:flex;
    align-items:center;
    justify-content:center;
    padding:24px;
  }
  .wrap{ width:100%; max-width:480px; }
  .brand{
    text-align:center;
    margin-bottom:22px;
  }
  .brand h1{
    font-size:34px;
    margin:0;
    letter-spacing:2px;
    font-weight:800;
    background:linear-gradient(90deg,var(--accent),var(--accent2));
    -webkit-background-clip:text;
    background-clip:text;
    color:transparent;
  }
  .brand p{
    margin:6px 0 0;
    color:var(--muted);
    font-size:13px;
    letter-spacing:1px;
    text-transform:uppercase;
  }
  .card{
    background:var(--card);
    border:1px solid var(--border);
    border-radius:16px;
    padding:22px;
    margin-bottom:16px;
    box-shadow:0 10px 30px rgba(0,0,0,0.35);
  }
  .status-row{
    display:flex;
    align-items:center;
    gap:10px;
    margin-bottom:14px;
  }
  .dot{
    width:10px;height:10px;border-radius:50%;
    background:#22c55e;
    box-shadow:0 0 10px #22c55e;
    animation:pulse 1.6s infinite;
  }
  @keyframes pulse{
    0%{opacity:1;} 50%{opacity:0.4;} 100%{opacity:1;}
  }
  .status-row span{ font-weight:600; }
  .grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:10px;
  }
  .stat{
    background:#0e0e16;
    border:1px solid var(--border);
    border-radius:10px;
    padding:10px 12px;
  }
  .stat .label{ font-size:11px; color:var(--muted); text-transform:uppercase; letter-spacing:0.5px;}
  .stat .value{ font-size:15px; font-weight:700; margin-top:2px; word-break:break-all;}
  .qr-card{ text-align:center; }
  .qr-card img{
    border-radius:10px;
    background:#fff;
    padding:8px;
  }
  .qr-card p{ color:var(--muted); font-size:12px; margin-top:10px;}
  .owner{
    text-align:center;
  }
  .owner h2{ margin:0 0 4px; font-size:18px; }
  .owner .role{ color:var(--muted); font-size:13px; margin-bottom:14px; }
  .contact{
    display:flex; gap:10px; justify-content:center; flex-wrap:wrap;
  }
  .contact a{
    text-decoration:none;
    color:var(--text);
    background:#1c1c28;
    border:1px solid var(--border);
    padding:8px 14px;
    border-radius:999px;
    font-size:13px;
    transition:0.2s;
  }
  .contact a:hover{ border-color:var(--accent); }
  footer{
    text-align:center;
    color:var(--muted);
    font-size:12px;
    margin-top:8px;
  }
  footer a{ color:var(--accent); text-decoration:none; }
</style>
</head>
<body>
  <div class="wrap">

    <div class="brand">
      <h1>THE KILLER</h1>
      <p>Mobile Hosting Server</p>
    </div>

    <div class="card">
      <div class="status-row">
        <div class="dot"></div>
        <span>Server Online</span>
      </div>
      <div class="grid">
        <div class="stat">
          <div class="label">Domain</div>
          <div class="value"><?php echo htmlspecialchars($host); ?></div>
        </div>
        <div class="stat">
          <div class="label">Server Time</div>
          <div class="value"><?php echo htmlspecialchars($serverTime); ?></div>
        </div>
        <div class="stat">
          <div class="label">PHP Version</div>
          <div class="value"><?php echo htmlspecialchars($phpVersion); ?></div>
        </div>
        <div class="stat">
          <div class="label">Total Visits</div>
          <div class="value"><?php echo number_format($visits); ?></div>
        </div>
      </div>
    </div>

    <div class="card qr-card">
      <img src="<?php echo htmlspecialchars($qrUrl); ?>" alt="QR code for this site" width="160" height="160">
      <p>Scan to open this site on another phone</p>
    </div>

    <div class="card owner">
      <h2><?php echo htmlspecialchars($ownerName); ?></h2>
      <div class="role">Server Owner</div>
      <div class="contact">
        <a href="tel:<?php echo htmlspecialchars($ownerPhone); ?>">📞 <?php echo htmlspecialchars($ownerPhone); ?></a>
        <a href="mailto:<?php echo htmlspecialchars($ownerEmail); ?>">✉️ Email</a>
      </div>
    </div>

    <footer>
      Powered by <a href="?">The Killer</a> — Termux + PHP + Cloudflare Tunnel
    </footer>

  </div>
</body>
</html>
